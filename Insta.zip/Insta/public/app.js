// ── Guardian AI — Frontend ──

const WS_URL = `ws://${location.host}`;
const CAPTURE_INTERVAL = 2000; // 2 seconds between frames

let ws;
let videoStream;
let audioContext, analyser, audioData;
let captureTimer;
let sessionStart = Date.now();
let stats = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
let map, hospitalMarkers = [], incidentMarkers = [];

// ── Initialize ──
document.addEventListener('DOMContentLoaded', () => {
  initWebSocket();
  initCamera();
  initAudio();
  initMap();
  initClock();
  checkOllamaStatus();
  loadDataSfFeed();
});

// ── WebSocket ──
function initWebSocket() {
  ws = new WebSocket(WS_URL);

  ws.onopen = () => console.log('WebSocket connected');

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === 'incident') {
      handleIncident(msg.data);
    }
  };

  ws.onclose = () => {
    console.log('WebSocket disconnected, reconnecting...');
    setTimeout(initWebSocket, 3000);
  };
}

// ── Camera ──
async function initCamera() {
  const video = document.getElementById('video');
  const cameraStatus = document.getElementById('cameraStatus');

  try {
    videoStream = await navigator.mediaDevices.getUserMedia({
      video: { width: 640, height: 480, facingMode: 'environment' },
      audio: false,
    });
    video.srcObject = videoStream;
    cameraStatus.className = 'dot green';

    // Start capturing frames
    captureTimer = setInterval(captureAndSend, CAPTURE_INTERVAL);
  } catch (err) {
    console.error('Camera error:', err);
    cameraStatus.className = 'dot red';
    document.getElementById('analysisLabel').textContent = 'Camera access denied';
  }
}

function captureAndSend() {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;

  const video = document.getElementById('video');
  const canvas = document.getElementById('captureCanvas');
  canvas.width = 640;
  canvas.height = 480;

  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, 640, 480);

  // Get base64 image (strip data URI prefix)
  const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
  const base64 = dataUrl.split(',')[1];

  // Check audio level for distress
  const audioAlert = checkAudioLevel();

  ws.send(JSON.stringify({
    type: 'frame',
    image: base64,
    audioAlert,
    timestamp: Date.now(),
  }));

  document.getElementById('analysisLabel').textContent = 'Analyzing...';
}

// ── Audio Monitoring ──
async function initAudio() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioContext = new AudioContext();
    const source = audioContext.createMediaStreamSource(stream);
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);
    audioData = new Uint8Array(analyser.frequencyBinCount);
  } catch (err) {
    console.log('Audio not available:', err.message);
  }
}

function checkAudioLevel() {
  if (!analyser) return false;

  analyser.getByteFrequencyData(audioData);
  const avg = audioData.reduce((a, b) => a + b, 0) / audioData.length;
  const level = Math.min(100, (avg / 128) * 100);

  // Update meter UI
  const meter = document.getElementById('audioMeter');
  meter.style.width = level + '%';
  meter.className = 'audio-meter-fill' +
    (level > 70 ? ' danger' : level > 40 ? ' warn' : '');

  // Threshold for distress (loud sound)
  return level > 75;
}

// Update audio meter periodically
setInterval(() => checkAudioLevel(), 100);

// ── Map ──
function initMap() {
  map = L.map('map', { zoomControl: false }).setView([37.7749, -122.4194], 13);

  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    maxZoom: 19,
  }).addTo(map);

  // Load hospitals (DataSF Health Care Facilities)
  fetch('/api/hospitals')
    .then((r) => r.json())
    .then((hospitals) => {
      document.getElementById('hospitalCount').textContent = hospitals.length + ' facilities';

      hospitals.forEach((h) => {
        const color = h.facility_type === 'General Acute Care Hospital' ? '#ef4444'
          : h.facility_type === 'Acute Psychiatric Hospital' ? '#f97316' : '#22c55e';
        const icon = L.divIcon({
          className: '',
          html: `<div style="
            background: ${color};
            width: 10px; height: 10px; border-radius: 50%;
            border: 2px solid white; box-shadow: 0 0 6px rgba(0,0,0,0.5);
          "></div>`,
          iconSize: [14, 14],
          iconAnchor: [7, 7],
        });

        const marker = L.marker([h.lat, h.lng], { icon }).addTo(map);
        marker.bindPopup(`
          <div style="color:#e2e8f0; font-size:12px;">
            <strong>${h.name}</strong><br>
            ${h.facility_type}<br>
            ${h.address}<br>
            ${h.services ? `<span style="color:#94a3b8">${h.services}</span><br>` : ''}
            <em>Source: DataSF</em>
          </div>
        `, { className: 'hospital-popup' });
        hospitalMarkers.push(marker);
      });
    });

  // Load crime hotspot zones (DataSF Fire/EMS + Police data)
  fetch('/api/hotspots')
    .then((r) => r.json())
    .then((hotspots) => {
      hotspots.forEach((h) => {
        const color = {
          CRITICAL: '#ef4444',
          HIGH: '#f97316',
          MEDIUM: '#eab308',
          LOW: '#22c55e',
        }[h.riskLevel] || '#94a3b8';

        // Draw a translucent circle for each hotspot zone
        L.circle([h.lat, h.lng], {
          radius: 500,
          color,
          fillColor: color,
          fillOpacity: 0.1,
          weight: 1,
          dashArray: '4, 4',
        }).addTo(map).bindPopup(`
          <div style="color:#e2e8f0; font-size:12px;">
            <strong>${h.neighborhood}</strong> — ${h.riskLevel} Risk<br>
            Medical calls: ${h.medicalIncidents.toLocaleString()}<br>
            Assaults: ${h.assaults.toLocaleString()}<br>
            Robberies: ${h.robberies.toLocaleString()}<br>
            Homicides: ${h.homicides}<br>
            <em>Source: DataSF (2024+)</em>
          </div>
        `, { className: 'hospital-popup' });
      });
    });
}

function addIncidentMarker(incident) {
  if (!incident.cameraLocation) return;

  const { lat, lng } = incident.cameraLocation;
  const color = {
    CRITICAL: '#ef4444',
    HIGH: '#f97316',
    MEDIUM: '#eab308',
    LOW: '#22c55e',
  }[incident.severity] || '#94a3b8';

  const icon = L.divIcon({
    className: '',
    html: `<div style="
      background: ${color}; width: 14px; height: 14px;
      border-radius: 50%; border: 2px solid white;
      box-shadow: 0 0 10px ${color};
      animation: pulse 1s infinite;
    "></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9],
  });

  const marker = L.marker([lat, lng], { icon }).addTo(map);
  marker.bindPopup(`
    <div style="color:#e2e8f0; font-size:12px;">
      <strong>${incident.severity}</strong>: ${incident.description}<br>
      ${new Date(incident.timestamp).toLocaleTimeString()}
    </div>
  `, { className: 'hospital-popup' });

  incidentMarkers.push(marker);

  // Draw line to nearest hospital if HIGH or CRITICAL
  if ((incident.severity === 'CRITICAL' || incident.severity === 'HIGH') && incident.nearestHospitals?.length) {
    const h = incident.nearestHospitals[0];
    L.polyline([[lat, lng], [h.lat, h.lng]], {
      color,
      weight: 2,
      dashArray: '8, 4',
      opacity: 0.7,
    }).addTo(map);

    map.flyTo([lat, lng], 14, { duration: 1 });
  }
}

// ── Handle Incident ──
function handleIncident(incident) {
  // Update severity banner
  const banner = document.getElementById('severityBanner');
  banner.className = `severity-banner ${incident.severity}`;
  banner.textContent = incident.severity === 'LOW'
    ? 'ALL CLEAR'
    : `${incident.severity} — ${incident.description}`;

  // Update analysis label
  document.getElementById('analysisLabel').textContent = incident.description;

  // Update stats
  stats[incident.severity]++;
  document.getElementById('criticalCount').textContent = stats.CRITICAL;
  document.getElementById('highCount').textContent = stats.HIGH;
  document.getElementById('mediumCount').textContent = stats.MEDIUM;
  document.getElementById('lowCount').textContent = stats.LOW;
  document.getElementById('incidentCount').textContent =
    Object.values(stats).reduce((a, b) => a + b, 0) + ' incidents';

  // Add to incident log (skip LOW unless it's the first)
  if (incident.severity !== 'LOW' || Object.values(stats).reduce((a, b) => a + b, 0) <= 1) {
    addIncidentToLog(incident);
  }

  // Add map marker for non-LOW
  if (incident.severity !== 'LOW') {
    addIncidentMarker(incident);
  }

  // Update nearest hospital card
  if (incident.nearestHospitals?.length) {
    const h = incident.nearestHospitals[0];
    document.getElementById('nearestHospitalCard').style.display = 'block';
    document.getElementById('nearestName').textContent = h.name;
    document.getElementById('nearestAddress').textContent = h.address;
    document.getElementById('nearestPhone').textContent = h.facility_type;
    document.getElementById('nearestDistance').textContent =
      `${h.distance.toFixed(1)} mi away`;
  }

  // Voice alert for HIGH and CRITICAL
  if (incident.severity === 'CRITICAL') {
    speakAlert(`Critical alert. ${incident.description}. Dispatching emergency services.`);
  } else if (incident.severity === 'HIGH') {
    speakAlert(`High severity. ${incident.description}.`);
  }

  // Auto-trigger 911 simulation for CRITICAL
  if (incident.simulatedCall) {
    simulate911Call(incident);
  }
}

function addIncidentToLog(incident) {
  const log = document.getElementById('incidentLog');

  // Remove empty state
  const empty = log.querySelector('.empty-state');
  if (empty) empty.remove();

  const time = new Date(incident.timestamp).toLocaleTimeString();
  const div = document.createElement('div');
  div.className = `incident-item ${incident.severity} new`;
  div.innerHTML = `
    <div class="incident-severity ${incident.severity}">${incident.severity}</div>
    <div class="incident-details">
      <div class="incident-desc">${incident.description}</div>
      <div class="incident-meta">${time} · ${incident.id} · ${incident.personCount || 0} persons · ${incident.neighborhood || ''}</div>
      ${incident.severity !== 'LOW' ? `<div class="incident-action">${incident.actionRequired}</div>` : ''}
    </div>
  `;

  log.prepend(div);

  // Remove 'new' animation class after it plays
  setTimeout(() => div.classList.remove('new'), 1000);
}

// ── 911 Simulation ──
function simulate911Call(incident) {
  const btn = document.getElementById('call911Btn');
  const sim = document.getElementById('callSimulation');

  btn.classList.add('active');
  sim.classList.add('visible');

  if (incident) {
    document.getElementById('callIncidentDesc').textContent = incident.description;
    if (incident.nearestHospitals?.length) {
      const nh = incident.nearestHospitals[0];
      document.getElementById('callHospital').textContent =
        `${nh.name} — ${nh.distance.toFixed(1)} mi`;
    }
  }

  // Auto-dismiss after 10 seconds
  setTimeout(() => {
    btn.classList.remove('active');
  }, 10000);
}

// ── Clock & Session Timer ──
function initClock() {
  function update() {
    document.getElementById('clock').textContent = new Date().toLocaleTimeString();

    const elapsed = Math.floor((Date.now() - sessionStart) / 1000);
    const h = String(Math.floor(elapsed / 3600)).padStart(2, '0');
    const m = String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0');
    const s = String(elapsed % 60).padStart(2, '0');
    document.getElementById('sessionTime').textContent = `${h}:${m}:${s}`;
  }
  update();
  setInterval(update, 1000);
}

// ── Ollama Status Check ──
async function checkOllamaStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    const dot = document.getElementById('ollamaStatus');
    const label = document.getElementById('ollamaLabel');

    if (data.ollama === 'connected' && data.modelLoaded) {
      dot.className = 'dot green';
      label.textContent = `Ollama (${data.model})`;
    } else if (data.ollama === 'connected') {
      dot.className = 'dot yellow';
      label.textContent = `Ollama (no model)`;
    } else {
      dot.className = 'dot red';
      label.textContent = 'Ollama (offline)';
    }
  } catch {
    document.getElementById('ollamaStatus').className = 'dot red';
    document.getElementById('ollamaLabel').textContent = 'Ollama (offline)';
  }

  // Re-check every 30s
  setTimeout(checkOllamaStatus, 30000);
}

// ── DataSF Live Feed ──
async function loadDataSfFeed() {
  const feed = document.getElementById('dataSfFeed');
  try {
    const [emsRes, policeRes] = await Promise.all([
      fetch('/api/datasf/ems-recent?limit=10'),
      fetch('/api/datasf/police-recent?limit=10'),
    ]);
    const emsCalls = await emsRes.json();
    const policeIncidents = await policeRes.json();

    const items = [];

    emsCalls.forEach((c) => {
      items.push({
        type: 'EMS',
        desc: c.call_type || c.call_type_group || 'Medical',
        location: c.neighborhoods_analysis_boundaries || c.neighborhood_district || '',
        date: c.received_datetime || c.call_date || '',
        color: '#3b82f6',
      });
    });

    policeIncidents.forEach((p) => {
      items.push({
        type: 'POLICE',
        desc: p.incident_category || p.incident_subcategory || 'Incident',
        location: p.analysis_neighborhood || '',
        date: p.incident_datetime || p.incident_date || '',
        color: '#f97316',
      });
    });

    // Sort by date descending
    items.sort((a, b) => new Date(b.date) - new Date(a.date));

    feed.innerHTML = items.slice(0, 15).map((item) => `
      <div style="display:flex; gap:6px; padding:4px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
        <span style="color:${item.color}; font-weight:600; min-width:48px;">${item.type}</span>
        <span style="flex:1; color:var(--text-primary);">${item.desc}</span>
        <span style="color:var(--text-secondary); white-space:nowrap;">${item.location}</span>
      </div>
    `).join('');
  } catch (err) {
    feed.innerHTML = '<div style="color:var(--text-secondary); text-align:center; padding:8px;">Failed to load DataSF feed</div>';
  }
}

// ── Voice Alert System (Web Speech API) ──
let voiceEnabled = true;
let lastVoiceAlert = 0;

function speakAlert(text) {
  if (!voiceEnabled || !window.speechSynthesis) return;
  // Throttle: no more than one alert every 5 seconds
  const now = Date.now();
  if (now - lastVoiceAlert < 5000) return;
  lastVoiceAlert = now;

  // Cancel any ongoing speech
  speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.1;
  utterance.pitch = 0.9;
  utterance.volume = 1;
  // Prefer a professional-sounding voice
  const voices = speechSynthesis.getVoices();
  const preferred = voices.find((v) => v.name.includes('Google') || v.name.includes('Microsoft')) || voices[0];
  if (preferred) utterance.voice = preferred;
  speechSynthesis.speak(utterance);
}

// ── Demo / Showcase Mode ──
let demoMode = false;
let demoTimer = null;

const demoScenarios = [
  { severity: 'LOW', description: 'Normal pedestrian activity on sidewalk. No threats detected.', threats: [], personCount: 4, actionRequired: 'No action required. Continue monitoring.' },
  { severity: 'LOW', description: 'Person sitting on bench using phone. Routine activity.', threats: [], personCount: 1, actionRequired: 'No action required.' },
  { severity: 'MEDIUM', description: 'Individual checking car windows in dimly lit parking area.', threats: ['Suspicious surveillance', 'Possible vehicle break-in'], personCount: 1, actionRequired: 'Alert security to monitor. Track individual.' },
  { severity: 'MEDIUM', description: 'Person pacing nervously near ATM. Looking around frequently.', threats: ['Suspicious behavior near ATM'], personCount: 1, actionRequired: 'Increase monitoring. Alert security.' },
  { severity: 'HIGH', description: 'Physical altercation between two individuals. Punches thrown.', threats: ['Active fight', 'Risk of injury'], personCount: 3, actionRequired: 'Dispatch security. Call police if escalating.' },
  { severity: 'HIGH', description: 'Person fallen on stairs, holding ankle. Appears injured.', threats: ['Fall injury', 'Possible fracture'], personCount: 1, actionRequired: 'Dispatch EMS. Person may need medical assistance.' },
  { severity: 'CRITICAL', description: 'Person lying motionless on ground. Not responding to passersby.', threats: ['Unresponsive person', 'Medical emergency'], personCount: 2, actionRequired: 'Call 911 immediately. Dispatch EMS.' },
  { severity: 'LOW', description: 'Delivery truck unloading packages. Normal commercial activity.', threats: [], personCount: 2, actionRequired: 'No action required.' },
  { severity: 'MEDIUM', description: 'Group loitering near closed storefront after hours.', threats: ['After-hours loitering', 'Possible trespassing'], personCount: 4, actionRequired: 'Monitor situation. Notify security if behavior changes.' },
  { severity: 'HIGH', description: 'Person smashing car window with object. Vehicle break-in in progress.', threats: ['Vehicle burglary', 'Property destruction'], personCount: 1, actionRequired: 'Call 911. Vehicle burglary in progress.' },
  { severity: 'CRITICAL', description: 'Multiple people fleeing building. Smoke visible from second floor.', threats: ['Structure fire', 'Smoke inhalation risk', 'Possible trapped occupants'], personCount: 8, actionRequired: 'Call 911. Dispatch fire department. Confirm evacuation.' },
  { severity: 'LOW', description: 'Cyclist in bike lane wearing helmet. Normal traffic.', threats: [], personCount: 1, actionRequired: 'No action required.' },
];

function startDemoMode() {
  demoMode = true;
  let idx = 0;
  const btn = document.getElementById('demoBtn');
  if (btn) { btn.textContent = 'Stop Demo'; btn.classList.add('active'); }

  // Stop real camera capture
  if (captureTimer) clearInterval(captureTimer);

  function nextDemo() {
    if (!demoMode) return;
    const scenario = demoScenarios[idx % demoScenarios.length];
    const cameraLat = 37.7749 + (Math.random() - 0.5) * 0.03;
    const cameraLng = -122.4194 + (Math.random() - 0.5) * 0.03;

    const incident = {
      id: `DEMO-${Date.now()}`,
      timestamp: new Date().toISOString(),
      severity: scenario.severity,
      description: scenario.description,
      threats: scenario.threats,
      personCount: scenario.personCount,
      actionRequired: scenario.actionRequired,
      cameraLocation: { lat: cameraLat, lng: cameraLng },
      nearestHospitals: [],
      neighborhood: ['Tenderloin', 'Mission', 'SoMa', 'Financial District', 'Castro', 'Sunset'][Math.floor(Math.random() * 6)],
      simulatedCall: scenario.severity === 'CRITICAL',
    };

    // Fetch nearest hospitals for this demo location
    fetch(`/api/hospitals?lat=${cameraLat}&lng=${cameraLng}`)
      .then((r) => r.json())
      .then((h) => {
        incident.nearestHospitals = h.slice(0, 3);
        handleIncident(incident);
      })
      .catch(() => handleIncident(incident));

    idx++;
    demoTimer = setTimeout(nextDemo, 4000 + Math.random() * 3000);
  }

  nextDemo();
}

function stopDemoMode() {
  demoMode = false;
  if (demoTimer) clearTimeout(demoTimer);
  const btn = document.getElementById('demoBtn');
  if (btn) { btn.textContent = 'Demo Mode'; btn.classList.remove('active'); }

  // Resume camera capture
  if (videoStream) {
    captureTimer = setInterval(captureAndSend, CAPTURE_INTERVAL);
  }
}

function toggleDemo() {
  if (demoMode) stopDemoMode();
  else startDemoMode();
}
