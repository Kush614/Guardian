# Guardian AI — Real-Time Security Monitor

AI-powered security camera system using on-device Gemma 3 4B for real-time threat detection. Classifies incidents by severity, recommends nearest SF hospital/route, and simulates 911 dispatch for critical emergencies.

## Why On-Device?

- **Privacy**: Security footage never leaves the local machine
- **Latency**: Sub-second analysis for emergency response
- **Reliability**: Works offline in areas with poor connectivity

## Quick Start

### 1. Install Ollama & pull Gemma 3

```bash
# Install Ollama from https://ollama.com
ollama pull gemma3:4b
```

### 2. Run the app

```bash
npm install
npm start
```

Open **http://localhost:3000** in your browser.

### 3. Grant permissions

Allow camera and microphone access when prompted.

## How It Works

1. **Frame Capture**: Webcam captures frames every 2 seconds
2. **Vision Analysis**: Gemma 3 4B analyzes each frame for threats via Ollama
3. **Audio Monitoring**: Web Audio API detects loud sounds (screams, impacts)
4. **Threat Classification**: AI classifies severity as CRITICAL / HIGH / MEDIUM / LOW
5. **Agentic Response**:
   - **CRITICAL**: Auto-simulates 911 call, shows nearest trauma center
   - **HIGH**: Alerts security, shows nearest hospital route
   - **MEDIUM**: Logs incident, continues monitoring
   - **LOW**: Normal activity, no action

## Fine-Tuning (Optional)

Open `fine-tune/finetune_gemma.ipynb` in Google Colab to LoRA fine-tune Gemma on security scenarios. After fine-tuning:

```bash
ollama create guardian-ai -f Modelfile
MODEL=guardian-ai npm start
```

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Backend | Node.js + Express |
| Frontend | Vanilla HTML/CSS/JS |
| AI Model | Gemma 3 4B (vision) via Ollama |
| Maps | Leaflet.js + CARTO dark tiles |
| Audio | Web Audio API |
| Real-time | WebSocket |
| Fine-tuning | LoRA via Hugging Face PEFT |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Server port |
| `OLLAMA_URL` | `http://localhost:11434` | Ollama API endpoint |
| `MODEL` | `gemma3:4b` | Ollama model name |

## Hardware Requirements

- **GPU**: GTX 1650 (4GB VRAM) or better for Gemma 3 4B Q4
- **RAM**: 8GB minimum
- **Webcam**: Any USB/built-in camera
