const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const PORT = process.env.PORT || 3000;
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';
const MODEL = process.env.MODEL || 'gemma3:4b';

// Serve static files
app.use(express.static('public'));
app.use(express.json({ limit: '10mb' }));

// ── Load all DataSF datasets from local files ──
const DATA_DIR = path.join(__dirname, 'data', 'datasf');

// 1. Healthcare facilities (all 78 from DataSF jhsu-2pka)
const allFacilities = JSON.parse(
  fs.readFileSync(path.join(DATA_DIR, 'healthcare_facilities.json'), 'utf-8')
);

// Build hospitals list: only facilities with valid coordinates
const hospitals = allFacilities
  .filter((f) => f.location?.latitude && f.location?.longitude)
  .map((f) => ({
    name: f.facility_name,
    facility_type: f.facility_type,
    services: f.services || '',
    lat: parseFloat(f.location.latitude),
    lng: parseFloat(f.location.longitude),
    address: `${f.location.human_address ? JSON.parse(f.location.human_address).address : f.location.address || ''}, San Francisco, CA`,
    source: 'DataSF',
  }));

// Curated subset: only General Acute Care Hospitals (for emergency routing)
const emergencyHospitals = hospitals.filter(
  (h) => h.facility_type === 'General Acute Care Hospital'
);

// 2. Fire/EMS dispatch calls (5000 most recent from DataSF nuek-vuh3)
const emsCalls = JSON.parse(
  fs.readFileSync(path.join(DATA_DIR, 'fire_ems_calls.json'), 'utf-8')
);

// 3. Police incident reports (5000 most recent violent crimes from DataSF wg3w-h783)
const policeIncidents = JSON.parse(
  fs.readFileSync(path.join(DATA_DIR, 'police_incidents.json'), 'utf-8')
);

// 4. EMS aggregates by neighborhood
const emsAggregates = JSON.parse(
  fs.readFileSync(path.join(DATA_DIR, 'ems_by_neighborhood.json'), 'utf-8')
);

// 5. Crime aggregates by neighborhood
const crimeAggregates = JSON.parse(
  fs.readFileSync(path.join(DATA_DIR, 'crime_by_neighborhood.json'), 'utf-8')
);

// 6. Pre-computed hotspot data
const hotspotData = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'data', 'sf_incident_hotspots.json'), 'utf-8')
);
const hotspots = hotspotData.hotspots;

// Build neighborhood risk lookup from aggregates
const neighborhoodRisk = {};
for (const row of emsAggregates) {
  const name = row.neighborhoods_analysis_boundaries;
  if (!name) continue;
  if (!neighborhoodRisk[name]) neighborhoodRisk[name] = { medical: 0, crime: 0 };
  neighborhoodRisk[name].medical += parseInt(row.incident_count) || 0;
}
for (const row of crimeAggregates) {
  const name = row.analysis_neighborhood;
  if (!name) continue;
  if (!neighborhoodRisk[name]) neighborhoodRisk[name] = { medical: 0, crime: 0 };
  neighborhoodRisk[name].crime += parseInt(row.incident_count) || 0;
}

// In-memory incident log
const incidents = [];

console.log(`Loaded DataSF datasets:`);
console.log(`  Healthcare facilities: ${hospitals.length} (${emergencyHospitals.length} hospitals)`);
console.log(`  Fire/EMS calls: ${emsCalls.length}`);
console.log(`  Police incidents: ${policeIncidents.length}`);
console.log(`  EMS aggregates: ${emsAggregates.length} rows`);
console.log(`  Crime aggregates: ${crimeAggregates.length} rows`);
console.log(`  Neighborhood risk profiles: ${Object.keys(neighborhoodRisk).length}`);

// ── Utility: distance between two lat/lng points (Haversine) ──
function haversine(lat1, lng1, lat2, lng2) {
  const R = 3958.8; // miles
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ── Find nearest hospitals to a location ──
function findNearestHospitals(lat, lng, count = 3) {
  // Prioritize General Acute Care Hospitals for emergency routing
  return emergencyHospitals
    .map((h) => ({ ...h, distance: haversine(lat, lng, h.lat, h.lng) }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, count);
}

// ── Find nearest facility of any type ──
function findNearestFacilities(lat, lng, count = 5) {
  return hospitals
    .map((h) => ({ ...h, distance: haversine(lat, lng, h.lat, h.lng) }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, count);
}

// ── Find nearest incident hotspot (DataSF crime data) ──
function findNearestHotspot(lat, lng) {
  let nearest = null;
  let minDist = Infinity;
  for (const h of hotspots) {
    const d = haversine(lat, lng, h.lat, h.lng);
    if (d < minDist) { minDist = d; nearest = h; }
  }
  return nearest;
}

// ── Analyze frame with Ollama Gemma 3 vision ──
async function analyzeFrame(base64Image) {
  const prompt = `You are a security camera AI analyst. Analyze this image for safety threats.

Classify the scene into exactly ONE severity level:
- CRITICAL: Active violence, person down/unresponsive, weapon visible, fire/explosion
- HIGH: Physical altercation, person falling/fallen, someone in visible distress
- MEDIUM: Suspicious behavior, loitering in restricted area, aggressive body language
- LOW: Normal activity, no threats detected

Respond in this EXACT JSON format only, no other text:
{
  "severity": "LOW|MEDIUM|HIGH|CRITICAL",
  "description": "Brief description of what you see",
  "threats": ["list of specific threats detected"],
  "personCount": 0,
  "actionRequired": "recommended action"
}`;

  try {
    const response = await fetch(`${OLLAMA_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        prompt,
        images: [base64Image],
        stream: false,
        format: 'json',
        options: {
          temperature: 0.1,
          num_predict: 300,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama returned ${response.status}`);
    }

    const data = await response.json();
    return JSON.parse(data.response);
  } catch (err) {
    console.error('Ollama analysis error:', err.message);
    return null;
  }
}

// ── Agentic response engine ──
function processIncident(analysis, audioAlert) {
  const timestamp = new Date().toISOString();
  let severity = analysis?.severity || 'LOW';

  // Escalate if audio distress detected simultaneously
  if (audioAlert && severity === 'LOW') severity = 'MEDIUM';
  if (audioAlert && severity === 'MEDIUM') severity = 'HIGH';

  // Default SF location (Union Square area) — in production, use actual camera GPS
  const cameraLat = 37.7879;
  const cameraLng = -122.4074;

  const nearestHospitals = findNearestHospitals(cameraLat, cameraLng);

  // Check if camera is in a known hotspot zone (DataSF crime data)
  const nearestHotspot = findNearestHotspot(cameraLat, cameraLng);

  const incident = {
    id: `INC-${Date.now()}`,
    timestamp,
    severity,
    description: analysis?.description || 'Audio distress detected',
    threats: analysis?.threats || (audioAlert ? ['Loud sound / scream detected'] : []),
    personCount: analysis?.personCount || 0,
    actionRequired: analysis?.actionRequired || 'Monitor',
    nearestHospitals,
    cameraLocation: { lat: cameraLat, lng: cameraLng },
    neighborhood: nearestHotspot?.neighborhood || 'Unknown',
    neighborhoodRisk: nearestHotspot?.riskLevel || 'LOW',
    simulatedCall: false,
  };

  // Severity-based response
  if (severity === 'CRITICAL') {
    incident.actionRequired = `EMERGENCY: Auto-dialing 911. Nearest: ${nearestHospitals[0].name} (${nearestHospitals[0].distance.toFixed(1)} mi). Location: ${incident.neighborhood}`;
    incident.simulatedCall = true;
    console.log(`\n🚨 CRITICAL INCIDENT DETECTED — Simulating 911 call`);
    console.log(`   Nearest: ${nearestHospitals[0].name} — ${nearestHospitals[0].distance.toFixed(1)} mi`);
    console.log(`   Neighborhood: ${incident.neighborhood} (risk: ${incident.neighborhoodRisk})`);
  } else if (severity === 'HIGH') {
    incident.actionRequired = `ALERT: Dispatching security. Nearest facility: ${nearestHospitals[0].name} (${nearestHospitals[0].distance.toFixed(1)} mi). Area: ${incident.neighborhood}`;
    console.log(`\n⚠️  HIGH severity incident — ${incident.description}`);
  } else if (severity === 'MEDIUM') {
    incident.actionRequired = `Monitoring situation. Security notified. Area: ${incident.neighborhood}`;
  }

  // Store incident (keep last 100)
  incidents.unshift(incident);
  if (incidents.length > 100) incidents.pop();

  return incident;
}

// ── WebSocket: real-time frame analysis ──
wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data);

      if (msg.type === 'frame') {
        // Analyze frame with Gemma vision
        const analysis = await analyzeFrame(msg.image);
        const incident = processIncident(analysis, msg.audioAlert);

        // Send result back to all connected clients
        const payload = JSON.stringify({ type: 'incident', data: incident });
        wss.clients.forEach((client) => {
          if (client.readyState === 1) client.send(payload);
        });
      }

      if (msg.type === 'audio_alert') {
        const incident = processIncident(null, true);
        const payload = JSON.stringify({ type: 'incident', data: incident });
        wss.clients.forEach((client) => {
          if (client.readyState === 1) client.send(payload);
        });
      }
    } catch (err) {
      console.error('WebSocket message error:', err.message);
    }
  });

  ws.on('close', () => console.log('Client disconnected'));
});

// ── REST API ──
app.get('/api/hospitals', (req, res) => {
  const { lat, lng } = req.query;
  if (lat && lng) {
    res.json(findNearestHospitals(parseFloat(lat), parseFloat(lng), 5));
  } else {
    res.json(hospitals);
  }
});

app.get('/api/incidents', (req, res) => {
  res.json(incidents.slice(0, 50));
});

app.post('/api/analyze', async (req, res) => {
  const { image, audioAlert } = req.body;
  if (!image) return res.status(400).json({ error: 'No image provided' });

  const analysis = await analyzeFrame(image);
  const incident = processIncident(analysis, audioAlert);
  res.json(incident);
});

// ── Hotspots from DataSF ──
app.get('/api/hotspots', (req, res) => {
  res.json(hotspots);
});

// ── DataSF local data: recent EMS calls ──
app.get('/api/datasf/ems-recent', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 500);
  const callType = req.query.type;
  let filtered = emsCalls;
  if (callType) {
    filtered = filtered.filter((c) => c.call_type === callType);
  }
  res.json(filtered.slice(0, limit));
});

// ── DataSF local data: recent police incidents ──
app.get('/api/datasf/police-recent', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 500);
  const category = req.query.category;
  let filtered = policeIncidents;
  if (category) {
    filtered = filtered.filter((i) => i.incident_category === category);
  }
  res.json(filtered.slice(0, limit));
});

// ── DataSF aggregates: EMS by neighborhood ──
app.get('/api/datasf/ems-stats', (req, res) => {
  res.json(emsAggregates);
});

// ── DataSF aggregates: crime by neighborhood ──
app.get('/api/datasf/crime-stats', (req, res) => {
  res.json(crimeAggregates);
});

// ── All healthcare facilities (78 from DataSF) ──
app.get('/api/facilities', (req, res) => {
  const { lat, lng, type } = req.query;
  let result = hospitals;
  if (type) {
    result = result.filter((h) => h.facility_type.toLowerCase().includes(type.toLowerCase()));
  }
  if (lat && lng) {
    result = result
      .map((h) => ({ ...h, distance: haversine(parseFloat(lat), parseFloat(lng), h.lat, h.lng) }))
      .sort((a, b) => a.distance - b.distance);
  }
  res.json(result);
});

// ── Neighborhood risk profile ──
app.get('/api/neighborhood-risk', (req, res) => {
  const { name } = req.query;
  if (name && neighborhoodRisk[name]) {
    res.json({ neighborhood: name, ...neighborhoodRisk[name] });
  } else {
    res.json(neighborhoodRisk);
  }
});

// ── Health check / Ollama status ──
app.get('/api/status', async (req, res) => {
  try {
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/tags`);
    const ollamaData = await ollamaRes.json();
    const hasModel = ollamaData.models?.some((m) => m.name.startsWith(MODEL.split(':')[0]));
    res.json({
      server: 'running',
      ollama: 'connected',
      model: MODEL,
      modelLoaded: hasModel,
    });
  } catch {
    res.json({ server: 'running', ollama: 'disconnected', model: MODEL, modelLoaded: false });
  }
});

// ── Start ──
server.listen(PORT, () => {
  console.log(`\n🛡️  Guardian AI Security Monitor`);
  console.log(`   Dashboard:  http://localhost:${PORT}`);
  console.log(`   Model:      ${MODEL} via Ollama`);
  console.log(`   WebSocket:  ws://localhost:${PORT}`);
  console.log(`   Hospitals:  ${emergencyHospitals.length} emergency + ${hospitals.length} total facilities`);
  console.log(`   DataSF:     ${emsCalls.length} EMS calls + ${policeIncidents.length} police incidents loaded\n`);
});
